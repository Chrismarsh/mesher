dem_filename='../data/chro_small.tif'

max_area=5000**2
max_tolerance=10
min_area=30**2

lloyd_itr = 1
use_input_prj=False
do_smoothing = True
max_smooth_iter = 2
smoothing_scaling_factor = 1

MPI_nworkers = 1