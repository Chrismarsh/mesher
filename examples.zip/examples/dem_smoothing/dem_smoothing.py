dem_filename='../data/chro_small.tif'

max_area=5000**2
max_tolerance=10
min_area=30**2

# lloyd_itr=100
simplify=True
simplify_tol=100
simplify_buffer=-50
lloyd_itr = 1

do_smoothing = True
max_smooth_iter = 2
smoothing_scaling_factor = 1
